﻿namespace ProyectoRifa
{
    public class MisEndPoints
    {
        public static String GetGeoApifyEndPoint(String ciudad)
        {
            return "https://api.geoapify.com/v1/geocode/search?text=" + ciudad + "&format=json&apiKey=" + MiConfig.GeoApifyKey;
        }
    }
}
