﻿namespace ProyectoRifa.Entidades
{
    public class Pelicula
    {
        public string Titulo { get; set; }
        public DateTime Lanzamiento { get; set; }
    }
}
