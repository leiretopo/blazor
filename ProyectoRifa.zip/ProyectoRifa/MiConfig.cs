﻿namespace ProyectoRifa
{
    public class MiConfig
    {
        public static String GeoApifyKey = "902c788c26b9495d85d43bb66db8c554";
    }
}
